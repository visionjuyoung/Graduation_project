package kr.psk.kpu.capstone_application;

/*
 사용자 계정 정보 모델 클래스
 */
public class UserAccount {
    private String idToken; // firebase 고유 토큰 정보 (사용자 계정만 가질 수 있는 고유 키)
    private String id;
    private String password;

    public String getIdToken() {
        return idToken;
    }

    public void setIdToken(String idToken) {
        this.idToken = idToken;
    }

    public UserAccount() {}

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }
}
