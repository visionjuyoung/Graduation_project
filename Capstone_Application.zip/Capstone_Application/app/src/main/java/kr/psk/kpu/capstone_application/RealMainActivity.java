package kr.psk.kpu.capstone_application;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentTransaction;

import android.os.Bundle;
import android.view.MenuItem;

import com.google.android.material.bottomnavigation.BottomNavigationView;

public class RealMainActivity extends AppCompatActivity {
    private BottomNavigationView bottomNavigationView; // 바텀 네비게이션 뷰
    private FragmentManager fm = getSupportFragmentManager();
    private PictureFrag pf;
    private UserInfoFrag uif;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_real_main);

        bottomNavigationView = findViewById(R.id.bottomNavi);
        pf = new PictureFrag();
        uif = new UserInfoFrag();
        // 초기 프래그먼트 설정
        getSupportFragmentManager().beginTransaction().replace(R.id.main_frame, pf).commitNowAllowingStateLoss();


        bottomNavigationView.setOnNavigationItemSelectedListener(new BottomNavigationView.OnNavigationItemSelectedListener() {
            @Override
            public boolean onNavigationItemSelected(@NonNull MenuItem menuItem) {
            //    FragmentTransaction transaction = fm.beginTransaction();
                switch(menuItem.getItemId()){
                    case R.id.action_picture: {
                        getSupportFragmentManager().beginTransaction().replace(R.id.main_frame, pf).commitNowAllowingStateLoss();
                        return true;
                    }
                    case R.id.user_info: {
                        getSupportFragmentManager().beginTransaction().replace(R.id.main_frame, uif).commitNowAllowingStateLoss();
                        return true;
                    }
                    default: return false;
                }
        }
    });
}
}